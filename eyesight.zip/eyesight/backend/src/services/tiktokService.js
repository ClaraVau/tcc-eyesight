// Placeholder — implementar futuramente
